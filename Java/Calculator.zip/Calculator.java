import java.util.Scanner;

public class Calculator {
    private double value;

    //constructor
    Calculator() {
        this.value = 0.0;
    }

    //addition method
    public void add(double val) {
        this.value += val;
    }

    //subtraction method
    public void subtract(double val) {
        this.value -= val;
    }

    //multiplication method
    public void multiply(double val) {
        this.value *= val;
    }

    //division method
    public void divide(double val) {
        if (value != 0.0) {
            this.value /= val;
        } else {
            System.out.println("Error: cannot divide by 0");
        }
    }

    //Clear current value
    public void clear() {
        this.value = 0.0;
    }

    //returns current value
    public double getValue() {
        return this.value;
    }

    public static void main(String[] args) {
        //instantiate a calculator
        Calculator calc = new Calculator();

        //instantiate scanner for input
        Scanner scnr = new Scanner(System.in);

        //get input from user for 2 numbers
        double num1 = scnr.nextDouble();
        double num2 = scnr.nextDouble();

        //print initial value
        System.out.println(calc.getValue());

        //add first number and show value
        calc.add(num1);
        System.out.println(calc.getValue());

        //multiply value by 3 and show value
        calc.multiply(3);
        System.out.println(calc.getValue());

        //Subtract the second num from the value and show result
        calc.subtract(num2);
        System.out.println(calc.getValue());

        //Divide value by 2 and show result
        calc.divide(2);
        System.out.println(calc.getValue());

        //clear current value back to 0
        calc.clear();

        //close scanner stream
        scnr.close();
        System.out.println(calc.getValue());
    }
}


