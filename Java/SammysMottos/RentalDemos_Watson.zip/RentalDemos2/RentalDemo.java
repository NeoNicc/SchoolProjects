import javax.swing.JOptionPane;

public class RentalDemo {
    public static void main(String[] args) {
        //The following code is for use with the base class Rental
        Rental rental1 = new Rental();
        Rental rental2 = new Rental(inputContractNum(), inputRentalTime(), inputEquipmentType());

        //show welcome message
        displayMotto();
        
        //view charges for the 2 rentals above
        viewFinalCharges(rental1);
        viewFinalCharges(rental2);
    }
    //request number of minutes equipment was rented for
    public static int inputRentalTime() {
        while(true) {
            try {
                String rentalLengthInput = JOptionPane.showInputDialog(null, "How many minutes did you rent your equipment?");
                return Integer.parseInt(rentalLengthInput);
            } catch(NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "That's not a number of minutes.");
            }
        }
    }
    //request a contract number
    public static String inputContractNum() {
        String contractNumInput = JOptionPane.showInputDialog(null, "What is the Contract Number?");
        return contractNumInput;
    }

    public static void displayMotto() {
        JOptionPane.showMessageDialog(null, "SSSSSSSSSSSSSSSSSSSSSSSSSSS\nS Sammy's makes it fun in the sun! S\nSSSSSSSSSSSSSSSSSSSSSSSSSSS");
    }
    public static void viewFinalCharges(Rental rental) {
        int baseCharge = rental.getRentedHours() * 40;
        int additionalFees = rental.getMinutesOverHour();
        int moreAdditionalFees = rental.getEquipment().getEquipmentFee();
        int totalCost = baseCharge + additionalFees + moreAdditionalFees;

        //display pricing information
        JOptionPane.showMessageDialog(null, "Your contract number is " + rental.getContractNum() + ". \nYou rented your equipment for " + rental.getRentedHours() + " hours and " + rental.getMinutesOverHour() + " minutes. \nYou rented a/n " + rental.getEquipment().getEquipmentName() + ". For $" + rental.getEquipment().getEquipmentFee() + "\n" + rental.getEquipment().lessonPolicy() + "\nThe total cost today will be: $" + totalCost);
    }
    public static String inputEquipmentType() {
        String typeInput = JOptionPane.showInputDialog(null, "Enter the type of equipment you will use.\n" + Equipment.displayEquipmentNames());
        return typeInput;
    }
}
