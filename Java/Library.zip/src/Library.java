
public class Library {
	public LibraryItem[] items = new LibraryItem[25];
	public LibraryMember[] members = new LibraryMember[25];
	
	public void addItem(LibraryItem item) {
		for (int i=0; i<items.length; i++) {
			if (items[i] == null) {
				items[i] = item;
				break;
			}
		}
	}
	
	public void addMember(LibraryMember member) {
		for (int i=0; i<members.length; i++) {
			if (members[i] == null) {
				members[i] = member;
				break;
			}
		}
	}
	
	//override
	public String toString() {
		int itemCount = 0;
		int memberCount = 0;
		
		for (int i=0; i<items.length; i++) {
			if (items[i] != null) {
				itemCount += 1;
			}
		}
		
		for (int i=0; i<members.length; i++) {
			if (members[i] != null) {
				memberCount += 1;
			}
		}
		
		return "Library: Items - " + itemCount + ". Members - " + memberCount;
	}
}
