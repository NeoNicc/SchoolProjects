import javax.swing.JOptionPane;

public class RockPaperScissors {
    public static void main(String[] args) {
        Choices playerChoice;
        String playerInput = JOptionPane.showInputDialog(null, "Choose rock, paper, or scissors by typing 1, 2, or 3, respectively.");
        int input = Integer.parseInt(playerInput);
        if (input == 1) {
            playerChoice = Choices.rock;
        } else if (input == 2) {
            playerChoice = Choices.paper;
        } else {
            playerChoice = Choices.scissors;
        }
        JOptionPane.showMessageDialog(null, playerChoice.versus(Choices.randomChoice()));
    }
    enum Choices {
        rock, paper, scissors;

        private int value = determineValue();

        private int determineValue() {
            if(this == rock) {
                return 1;
            } else if (this == paper) {
                return 2;
            } else {
                return 3;
            }
        }
        public Choices getChoice() {
            return this;
        }
        public static Choices randomChoice() {
            Choices[] choices = Choices.values();
            int index = (int)(Math.random() * choices.length);
            return choices[index];
        }

        public String versus(Choices choice) {
            String result = "";
            JOptionPane.showMessageDialog(null, "You played: " + this.getChoice());
            switch(this.determineValue()) {
                case 1:
                if (choice.determineValue() == 1) {
                    JOptionPane.showMessageDialog(null, "Your opponent played: " + choice.getChoice());
                    return result = "It's a Draw!";
                } else if (choice.determineValue() == 2) {
                    JOptionPane.showMessageDialog(null, "Your opponent played: " + choice.getChoice());
                    return result = "You Lose!";
                } else {
                    JOptionPane.showMessageDialog(null, "Your opponent played: " + choice.getChoice());
                    return result = "You Win!";
                }
                case 2:
                if (choice.determineValue() == 2) {
                    JOptionPane.showMessageDialog(null, "Your opponent played: " + choice.getChoice());
                    return result = "It's a Draw!";
                } else if (choice.determineValue() == 3) {
                    JOptionPane.showMessageDialog(null, "Your opponent played: " + choice.getChoice());
                    return result = "You Lose!";
                } else {
                    JOptionPane.showMessageDialog(null, "Your opponent played: " + choice.getChoice());
                    return result = "You Win!";
                }

                case 3: 
                if (choice.determineValue() == 3) {
                    JOptionPane.showMessageDialog(null, "Your opponent played: " + choice.getChoice());
                    return result = "It's a Draw!";
                } else if (choice.determineValue() == 1) {
                    JOptionPane.showMessageDialog(null, "Your opponent played: " + choice.getChoice());
                    return result = "You Lose!";
                } else {
                    JOptionPane.showMessageDialog(null, "Your opponent played: " + choice.getChoice());
                    return result = "You Win!";
                }
            }
            return result;
        }
    }
}
